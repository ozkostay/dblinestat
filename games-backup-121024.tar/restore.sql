--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE games;
--
-- Name: games; Type: DATABASE; Schema: -; Owner: linestatuser
--

CREATE DATABASE games WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE games OWNER TO linestatuser;

\connect games

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: games; Type: TABLE; Schema: public; Owner: linestatuser
--

CREATE TABLE public.games (
    id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    sport integer NOT NULL,
    turnament integer NOT NULL,
    player1 integer NOT NULL,
    player2 integer NOT NULL,
    surface integer,
    result character varying,
    date timestamp without time zone
);


ALTER TABLE public.games OWNER TO linestatuser;

--
-- Name: games_id_seq; Type: SEQUENCE; Schema: public; Owner: linestatuser
--

CREATE SEQUENCE public.games_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_seq OWNER TO linestatuser;

--
-- Name: games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: linestatuser
--

ALTER SEQUENCE public.games_id_seq OWNED BY public.games.id;


--
-- Name: games id; Type: DEFAULT; Schema: public; Owner: linestatuser
--

ALTER TABLE ONLY public.games ALTER COLUMN id SET DEFAULT nextval('public.games_id_seq'::regclass);


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: linestatuser
--

COPY public.games (id, "timestamp", sport, turnament, player1, player2, surface, result, date) FROM stdin;
\.
COPY public.games (id, "timestamp", sport, turnament, player1, player2, surface, result, date) FROM '$$PATH$$/3393.dat';

--
-- Name: games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: linestatuser
--

SELECT pg_catalog.setval('public.games_id_seq', 17102, true);


--
-- Name: games PK_c9b16b62917b5595af982d66337; Type: CONSTRAINT; Schema: public; Owner: linestatuser
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT "PK_c9b16b62917b5595af982d66337" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

