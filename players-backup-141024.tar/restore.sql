--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE players;
--
-- Name: players; Type: DATABASE; Schema: -; Owner: linestatuser
--

CREATE DATABASE players WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE players OWNER TO linestatuser;

\connect players

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: players; Type: TABLE; Schema: public; Owner: linestatuser
--

CREATE TABLE public.players (
    id integer NOT NULL,
    name_ru character varying NOT NULL,
    name_en character varying NOT NULL,
    sport integer
);


ALTER TABLE public.players OWNER TO linestatuser;

--
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: linestatuser
--

CREATE SEQUENCE public.players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.players_id_seq OWNER TO linestatuser;

--
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: linestatuser
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- Name: players id; Type: DEFAULT; Schema: public; Owner: linestatuser
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: linestatuser
--

COPY public.players (id, name_ru, name_en, sport) FROM stdin;
\.
COPY public.players (id, name_ru, name_en, sport) FROM '$$PATH$$/3393.dat';

--
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: linestatuser
--

SELECT pg_catalog.setval('public.players_id_seq', 8413, true);


--
-- Name: players PK_de22b8fdeee0c33ab55ae71da3b; Type: CONSTRAINT; Schema: public; Owner: linestatuser
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT "PK_de22b8fdeee0c33ab55ae71da3b" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

