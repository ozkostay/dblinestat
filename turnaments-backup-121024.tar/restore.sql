--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE turnaments;
--
-- Name: turnaments; Type: DATABASE; Schema: -; Owner: linestatuser
--

CREATE DATABASE turnaments WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE turnaments OWNER TO linestatuser;

\connect turnaments

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: turnaments; Type: TABLE; Schema: public; Owner: linestatuser
--

CREATE TABLE public.turnaments (
    id integer NOT NULL,
    sport integer NOT NULL,
    name_ru character varying NOT NULL,
    name_en character varying NOT NULL,
    surface integer
);


ALTER TABLE public.turnaments OWNER TO linestatuser;

--
-- Name: turnaments_id_seq; Type: SEQUENCE; Schema: public; Owner: linestatuser
--

CREATE SEQUENCE public.turnaments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.turnaments_id_seq OWNER TO linestatuser;

--
-- Name: turnaments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: linestatuser
--

ALTER SEQUENCE public.turnaments_id_seq OWNED BY public.turnaments.id;


--
-- Name: turnaments id; Type: DEFAULT; Schema: public; Owner: linestatuser
--

ALTER TABLE ONLY public.turnaments ALTER COLUMN id SET DEFAULT nextval('public.turnaments_id_seq'::regclass);


--
-- Data for Name: turnaments; Type: TABLE DATA; Schema: public; Owner: linestatuser
--

COPY public.turnaments (id, sport, name_ru, name_en, surface) FROM stdin;
\.
COPY public.turnaments (id, sport, name_ru, name_en, surface) FROM '$$PATH$$/3393.dat';

--
-- Name: turnaments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: linestatuser
--

SELECT pg_catalog.setval('public.turnaments_id_seq', 351, true);


--
-- Name: turnaments PK_2600bf4fe514f6407c4a459b615; Type: CONSTRAINT; Schema: public; Owner: linestatuser
--

ALTER TABLE ONLY public.turnaments
    ADD CONSTRAINT "PK_2600bf4fe514f6407c4a459b615" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

